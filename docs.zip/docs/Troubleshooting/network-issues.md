# Troubleshooting Network Issues

## Symptoms
- No internet
- Slow speed

## Resolution
1. Check IP settings
2. Restart adapter