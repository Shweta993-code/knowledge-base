# How to Install Software

## Steps
1. Download installer
2. Run setup
3. Verify installation