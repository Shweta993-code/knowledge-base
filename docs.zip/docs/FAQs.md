# Frequently Asked Questions

**Q:** How do I reset my password?

**A:** Use the password reset tool.